﻿function sayWorld() {
    return "world";
}